// ===================================
// 1. MOBILE MENU TOGGLE & NAVIGATION
// ===================================
const mobileMenuToggle = document.querySelector(".mobile-menu-toggle")
const navMenu = document.querySelector(".nav-menu")

mobileMenuToggle.addEventListener("click", () => {
    mobileMenuToggle.classList.toggle("active")
    navMenu.classList.toggle("active")
})

// Close mobile menu when clicking on a link
// Close mobile menu when clicking on a link or mobile action button
const linksToCloseMenu = document.querySelectorAll(
    ".nav-link, .mobile-phone, .mobile-social a"
);

linksToCloseMenu.forEach((link) => {
    link.addEventListener("click", () => {
        // Cierra el menú y resetea el botón toggle
        mobileMenuToggle.classList.remove("active");
        navMenu.classList.remove("active");
    });
});
  

// Active Navigation Link on Scroll
window.addEventListener("load", () => {
    let current = ""
    // Secciones que tienen ID y están en el menú de navegación
    const sections = document.querySelectorAll("section[id]") 

    sections.forEach((section) => {
        const sectionTop = section.offsetTop
        // Ajuste el offset para compensar la altura de la barra de navegación fija (80px)
        if (scrollY >= sectionTop - 100) { 
            current = section.getAttribute("id")
        }
    })

    navLinks.forEach((link) => {
        link.classList.remove("active")
        if (link.getAttribute("href") === `#${current}`) {
            link.classList.add("active")
        }
    })
})


// ===================================
// 2. COMPARISON SLIDER FUNCTIONALITY (CORREGIDO)
// ===================================
const comparisonContainer = document.querySelector(".comparison-container")
const comparisonHandle = document.querySelector(".comparison-handle")
const comparisonAfter = document.querySelector(".comparison-after")

let isDragging = false

function updateComparison(x) {
    if (!comparisonContainer) return; // Salir si el contenedor no se encuentra

    const containerRect = comparisonContainer.getBoundingClientRect()
    const containerWidth = containerRect.width
    const offsetX = x - containerRect.left
    const percentage = Math.max(0, Math.min(100, (offsetX / containerWidth) * 100))

    comparisonHandle.style.left = `${percentage}%`
    // El clip-path usa el porcentaje para ocultar parte de la imagen 'after'
    comparisonAfter.style.clipPath = `inset(0 ${100 - percentage}% 0 0)` 
}

// Eventos de ratón para escritorio
comparisonHandle.addEventListener("mousedown", (e) => {
    e.preventDefault(); // Previene la selección de texto al arrastrar
    isDragging = true
    comparisonContainer.classList.add('dragging');
})

document.addEventListener("mousemove", (e) => {
    if (isDragging) {
        // Usar e.clientX para obtener la posición horizontal del cursor
        updateComparison(e.clientX) 
    }
})

document.addEventListener("mouseup", () => {
    isDragging = false
    comparisonContainer.classList.remove('dragging');
})

// Eventos táctiles para móvil
comparisonHandle.addEventListener("touchstart", (e) => {
    e.preventDefault();
    isDragging = true
    comparisonContainer.classList.add('dragging');
})

document.addEventListener("touchmove", (e) => {
    if (isDragging && e.touches.length > 0) {
        // Usar e.touches[0].clientX para la posición del primer toque
        updateComparison(e.touches[0].clientX) 
    }
})

document.addEventListener("touchend", () => {
    isDragging = false
    comparisonContainer.classList.remove('dragging');
})

// ===================================
// 3. VIDEO AUTOPLAY ON SCROLL
// ===================================
const galleryVideos = document.querySelectorAll(".gallery-video")

const videoObserver = new IntersectionObserver(
    (entries) => {
        entries.forEach((entry) => {
            const video = entry.target
            if (entry.isIntersecting) {
                video.play().catch((error) => {
                    console.log("[v0] Video autoplay prevented:", error)
                })
            } else {
                video.pause()
            }
        })
    },
    {
        threshold: 0.5,
    },
)

galleryVideos.forEach((video) => {
    videoObserver.observe(video)
})

// ===================================
// 4. GALLERY MODAL FUNCTIONALITY
// ===================================
const galleryItems = document.querySelectorAll(".gallery-item")
const galleryModal = document.getElementById("galleryModal")
const modalImage = document.getElementById("modalImage")
const modalVideo = document.getElementById("modalVideo")
const modalClose = document.querySelector(".modal-close")
const modalPrev = document.querySelector(".modal-prev")
const modalNext = document.querySelector(".modal-next")
const modalCounter = document.getElementById("modalCounter")

// IMPORTANTE: Asegúrate de que este número refleje el total de ítems en tu .gallery-grid
// (Actualizado a 3 videos + 1 foto = 4. Pero tu HTML solo tiene 3 videos)
// Si agregas una foto después, cambia este número a 4. Por ahora, lo dejo en 3:
const totalItems = 3 
// Si en el futuro tienes 4 ítems (como lo dice tu comentario en el HTML) usa: const totalItems = 4;

let currentIndex = 0 

function openModal(index) {
    currentIndex = index
    updateModalContent()
    galleryModal.classList.add("active")
    document.body.style.overflow = "hidden" // Bloquea el scroll del fondo
}

function closeModal() {
    galleryModal.classList.remove("active")
    document.body.style.overflow = ""

    // Pausa y esconde el video
    modalVideo.pause()
    modalVideo.style.display = "none"
    modalImage.style.display = "none"
}

function updateModalContent() {
    // Asegurarse de que el índice es válido
    if (currentIndex < 0 || currentIndex >= galleryItems.length) return; 

    const item = galleryItems[currentIndex]
    const type = item.getAttribute("data-type")

    // Resetear visibilidad
    modalImage.style.display = "none"
    modalVideo.style.display = "none"
    modalVideo.pause(); // Pausar antes de cambiar la fuente

    if (type === "video") {
        const videoSource = item.querySelector("source") ? item.querySelector("source").src : item.querySelector("video").src;
        modalVideo.querySelector("source").src = videoSource;
        modalVideo.load(); // Cargar la nueva fuente
        modalVideo.style.display = "block"
        modalVideo.play().catch(e => console.log("Modal video play error:", e));
    } else {
        const img = item.querySelector("img")
        modalImage.src = img.src
        modalImage.alt = img.alt
        modalImage.style.display = "block"
    }

    modalCounter.textContent = `${currentIndex + 1} / ${totalItems}`
}

function showPrev() {
    currentIndex = (currentIndex - 1 + totalItems) % totalItems
    updateModalContent()
}

function showNext() {
    currentIndex = (currentIndex + 1) % totalItems
    updateModalContent()
}

// Gallery item click handlers
galleryItems.forEach((item, index) => {
    item.addEventListener("click", () => {
        openModal(index)
    })
})

// Modal controls
modalClose.addEventListener("click", closeModal)
modalPrev.addEventListener("click", showPrev)
modalNext.addEventListener("click", showNext)

// Keyboard navigation
document.addEventListener("keydown", (e) => {
    if (!galleryModal.classList.contains("active")) return

    if (e.key === "Escape") closeModal()
    if (e.key === "ArrowLeft") showPrev()
    if (e.key === "ArrowRight") showNext()
})

// Close modal when clicking outside content
galleryModal.addEventListener("click", (e) => {
    // Solo cerrar si el clic es directamente en el fondo del modal
    if (e.target === galleryModal) {
        closeModal()
    }
})


// ===================================
// 5. SMOOTH SCROLL & INITIALIZATION
// ===================================
// Animate elements on scroll (Scroll Reveal Functionality)
const observerOptions = {
    threshold: 0.1, // El 10% del elemento debe ser visible para disparar la animación
    rootMargin: "0px 0px -50px 0px",
}

const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            // Cuando es visible, añade la clase 'visible'
            entry.target.classList.add('visible');
            // Deja de observar el elemento una vez que ha aparecido
            observer.unobserve(entry.target); 
        }
    })
}, observerOptions)

// Observar elementos con clases de revelado (Reveal Classes)
document.querySelectorAll(".reveal-up, .reveal-left, .reveal-right").forEach((el) => {
    revealObserver.observe(el);
});